import * as FlexPlugin from 'flex-plugin';
import BusinessHoursPlugin from './BusinessHoursPlugin';

FlexPlugin.loadPlugin(BusinessHoursPlugin);
